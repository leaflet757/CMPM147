

Gamepad HTML
http://www.html5rocks.com/en/tutorials/doodles/gamepad/
Has trouble connecting?

ZigFu
http://zigfu.com/en/zdk/javascript/

LeapMotion (x2)
works!

MakeyMakey
http://makeymakey.com/

Audio input
From mp3: verified
From live-audio source?